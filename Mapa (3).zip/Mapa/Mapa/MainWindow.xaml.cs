﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace Mapa
{
    public partial class MainWindow : Window
    {
        private List<Button> cityButtons = new List<Button>();
        private List<string> cities = new List<string> { "Praha", "Brno", "Ostrava" };
        private List<string> remainingCities; 
        private string currentCity = "";
        private Random rnd = new Random();

        private int score = 0;
        private int currentRound = 0;
        private int totalRounds;

        public MainWindow()
        {
            InitializeComponent();
            totalRounds = cities.Count; 
            remainingCities = new List<string>(cities);
            InitializeGame();
        }

        private void InitializeGame()
        {
           
            cityButtons.Add(CreateCityButton("Praha", 260, 145));
            cityButtons.Add(CreateCityButton("Brno", 500, 310));
            cityButtons.Add(CreateCityButton("Ostrava", 700, 200));

            foreach (Button btn in cityButtons)
            {
                MapCanvas.Children.Add(btn);
            }

            UpdateScoreDisplay();
            SetNextCity();
        }

        private Button CreateCityButton(string name, double x, double y)
        {
            Button btn = new Button
            {
                Content = name,
                Tag = name,
                Width = 70,
                Height = 30,
                
            };

            Canvas.SetLeft(btn, x);
            Canvas.SetTop(btn, y);

            btn.Click += CityButton_Click;
            return btn;
        }

        private void SetNextCity()
        {
            if (remainingCities.Count > 0)
            {
                currentRound++;
                int index = rnd.Next(remainingCities.Count);
                currentCity = remainingCities[index];

                ActiveCityText.Text = $"Kolo: {currentRound}/{totalRounds} | Hledej: {currentCity}";
            }
            else
            {
                MessageBox.Show($"Konec hry! Vaše finální skóre je: {score} z {totalRounds}", "Konec");
                ActiveCityText.Text = "Hra skončila";
            }
        }

        private void UpdateScoreDisplay()
        {
            ScoreText.Text = $"Skóre: {score}";
        }

        private void MapImage_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Point p = e.GetPosition(MapCanvas);
            MessageBox.Show($"Souřadnice: X = {p.X}, Y = {p.Y}", "Zjištění souřadnic");
        }

        private void CityButton_Click(object sender, RoutedEventArgs e)
        {
            if (remainingCities.Count == 0) return;

            Button clickedButton = sender as Button;

            
            if (clickedButton != null && clickedButton.Tag.ToString() == currentCity)
            {
                score++;
                MessageBox.Show("Správná odpověď!", "Výsledek");
            }
            else
            {
                MessageBox.Show($"Špatně! Hledali jste {currentCity}, ale klikli jste na {clickedButton.Tag}.", "Výsledek");
            }

            remainingCities.Remove(currentCity);
            UpdateScoreDisplay();
            SetNextCity();
        }
    }
}
﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Mapa
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        
        private List<Button> cityButtons = new List<Button>();
        private List<string> cities = new List<string> { "Praha", "Brno", "Ostrava" };
        private string currentCity = "";
        private Random rnd = new Random();

        public MainWindow()
        {
            InitializeComponent();
            InitializeGame();
        }

        private void InitializeGame()
        {
            
            cityButtons.Add(CreateCityButton("Praha", 260, 145));
            cityButtons.Add(CreateCityButton("Brno", 500, 310));
            cityButtons.Add(CreateCityButton("Ostrava", 700, 200));

          
            foreach (Button btn in cityButtons)
            {
                MapCanvas.Children.Add(btn);
            }

            SetNextCity();
        }

        private Button CreateCityButton(string name, double x, double y)
        {
            Button btn = new Button
            {
                Content = name,
                Tag = name,
                Width = 70,
                Height = 30,
                Background = Brushes.White
            };

            Canvas.SetLeft(btn, x);
            Canvas.SetTop(btn, y);

            btn.Click += CityButton_Click;
            return btn;
        }

        private void SetNextCity()
        {
          
            int index = rnd.Next(cities.Count);
            currentCity = cities[index];
            ActiveCityText.Text = "Hledej: " + currentCity;
        }

        private void MapImage_MouseDown(object sender, MouseButtonEventArgs e)
        {
           
            Point p = e.GetPosition(MapCanvas);
            MessageBox.Show($"Souřadnice: X = {p.X}, Y = {p.Y}", "Zjištění souřadnic");
        }

        private void CityButton_Click(object sender, RoutedEventArgs e)
        {
            Button clickedButton = sender as Button;

          
            if (clickedButton != null && clickedButton.Tag.ToString() == currentCity)
            {
                MessageBox.Show("Správná odpověď!", "Výsledek");
                SetNextCity();
            }
            else
            {
                MessageBox.Show("Špatně, toto město je " + clickedButton.Tag.ToString() + ".", "Výsledek");
            }
        }
    }
}